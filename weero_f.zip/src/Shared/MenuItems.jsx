// import { Link } from "react-router-dom";

// /* eslint-disable no-unused-vars */
// export const menuItems = (
//   <>
//     <li>
//       <Link to="/">
//         <p>Home</p>
//       </Link>
//     </li>
//     <li>
//       <Link to="/login">
//         <p>Log in</p>
//       </Link>
//     </li>
//     <li>
//       <Link to="/signup">
//         <p>Sign Up</p>
//       </Link>
//     </li>
//   </>
// );
