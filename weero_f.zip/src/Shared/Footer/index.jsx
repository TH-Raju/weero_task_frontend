const Footer = () => {
  //   console.log(theme);

  return <div></div>;
};

export default Footer;
